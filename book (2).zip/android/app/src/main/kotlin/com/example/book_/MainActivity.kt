package com.example.book_

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
